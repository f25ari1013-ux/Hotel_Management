package hotel_management;

public class Booking {
    private static int bookingCounter = 1;
    private int bookingId;
    private Room room;
    private Customer customer;
    private int days;
    private double mealCharges;
    private double services;
    private double discount;
    private double totalBill;

    public Booking(Room room, Customer customer, int days, double mealCharges) {

        if (room == null || customer == null) {
            throw new IllegalArgumentException("Room or Customer cannot be null");
        }

        this.bookingId = bookingCounter++;
        this.room = room;
        this.customer = customer;
        this.days = days;
        this.mealCharges = mealCharges;
        this.services = 50.0; // Fixed service charge
        this.discount = calculateAutoDiscount(); // Auto-calculate discount

        calculateBill();
    }

    private double calculateAutoDiscount() {
        // 5% discount if days > 2
        if (days > 2) {
            double subtotal = room.getPricePerDay() * days + mealCharges + services;
            return subtotal * 0.05;
        }
        return 0.0;
    }

    public double calculateBill() {
        double roomCharges = room.getPricePerDay() * days;
        totalBill = roomCharges + mealCharges + services - discount;

        // prevent negative bill
        if (totalBill < 0) {
            totalBill = 0;
        }

        return totalBill;
    }

    public double getServices() {
        return services;
    }

    public double getDiscount() {
        return discount;
    }

    public double getMealCharges() {
        return mealCharges;
    }

    public int getBookingId() {
        return bookingId;
    }

    public Room getRoom() {
        return room;
    }

    public Customer getCustomer() {
        return customer;
    }

    public int getDays() {
        return days;
    }

    public double getTotalBill() {
        return totalBill;
    }

    @Override
    public String toString() {
        return "Booking ID: " + bookingId +
                ", " + customer.getDetails() +
                ", Room: " + room.getRoomNo() +
                ", Days: " + days +
                ", Room Charges: " + (room.getPricePerDay() * days) +
                ", Meal Charges: " + mealCharges +
                ", Service Charges: " + services +
                ", Discount: " + String.format("%.2f", discount) +
                ", Total Bill: " + String.format("%.2f", totalBill);
    }
}