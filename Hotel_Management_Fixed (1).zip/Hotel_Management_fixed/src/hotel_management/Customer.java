/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel_management;
/**
 *
 * @author iAT
 */
public class Customer {
    // Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).

   private String name;
   private String id;
   private String phone;

   public Customer(String var1, String var2, String var3) {
      if (var1 != null && var2 != null && var3 != null) {
         this.name = var1;
         this.id = var2;
         this.phone = var3;
      } else {
         throw new IllegalArgumentException("Fields cannot be null");
      }
   }

   public String getName() {
      return this.name;
   }

   public String getId() {
      return this.id;
   }

   public String getPhone() {
      return this.phone;
   }

   public String getDetails() {
      return "Name: " + this.name + ", ID: " + this.id + ", Phone: " + this.phone;
   }

   public String toString() {
      return this.getDetails();
   }
}


