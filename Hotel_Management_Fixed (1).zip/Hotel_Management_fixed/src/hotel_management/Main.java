package hotel_management;

import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class Main {
    private static Hotel hotel = new Hotel();

    // Colors
    static final Color SIDEBAR_BG    = new Color(13, 71, 161);
    static final Color SIDEBAR_SEL   = new Color(21, 101, 192);
    static final Color CONTENT_BG    = new Color(240, 244, 255);
    static final Color CARD_BG       = Color.WHITE;
    static final Color TEXT_DARK     = new Color(20, 30, 60);
    static final Color TEXT_GRAY     = new Color(110, 120, 150);
    static final Color ACCENT_BLUE   = new Color(33, 150, 243);
    static final Color ACCENT_GREEN  = new Color(76, 175, 80);
    static final Color ACCENT_ORANGE = new Color(255, 152, 0);
    static final Color ACCENT_PURPLE = new Color(156, 39, 176);
    static int bookingCounter = 1000;
    static int customerCounter = 2000;
    static int roomCounter = 3000;
    static final Color CONFIRMED_CLR = new Color(76, 175, 80);

    static JPanel contentPanel;
    static CardLayout cardLayout;
    static JLabel dateLabel, timeLabel;
    static JPanel dashboardPanel;
    static JPanel reportsPanel;

    public static void main(String[] args) {
        // --- SQL connection: graceful, non-blocking ---
        tryConnectDB();

        hotel.addRoom(new Room(101, "Single", 100.0));
        hotel.addRoom(new Room(102, "Double", 150.0));
        hotel.addRoom(new Room(103, "Suite",  250.0));
        hotel.addRoom(new Room(104, "Single", 100.0));
        hotel.addRoom(new Room(105, "Double", 150.0));
        hotel.setName("Sunrise Hotel");
        hotel.setLocation("Mumbai");
        hotel.setContact("+91 22 1234 5678");
        hotel.loadBookingsFromFile();

        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception ignored) {}

        SwingUtilities.invokeLater(Main::createAndShowGUI);
    }

    /** Try DB connection silently — never blocks startup */
    private static void tryConnectDB() {
        new Thread(() -> {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                java.sql.Connection con = java.sql.DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel_booking?connectTimeout=3000",
                    "root", ""
                );
                System.out.println("Hotel Database Connected Successfully! ✅");
                con.close();
            } catch (ClassNotFoundException e) {
                System.out.println("ℹ️  MySQL driver not found — running without DB.");
            } catch (Exception e) {
                System.out.println("ℹ️  DB not available — running in standalone mode.");
            }
        }, "db-check").start();
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Hotel Management System");

        // Background panel covers the full window
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());

        JPanel root = new JPanel(new BorderLayout());
        root.setOpaque(false);  // must be transparent so background shows through

        root.add(buildSidebar(frame), BorderLayout.WEST);
        root.add(buildMainArea(), BorderLayout.CENTER);

        backgroundPanel.add(root);
        frame.setContentPane(backgroundPanel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1100, 700);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        javax.swing.Timer clock = new javax.swing.Timer(1000, e -> updateClock());
        clock.start();
        updateClock();
    }

    // ─── SIDEBAR ────────────────────────────────────────────────────────────────
    static JPanel buildSidebar(JFrame frame) {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Semi-transparent sidebar so background image peeks through
                g2.setColor(new Color(13, 71, 161, 220));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        sidebar.setLayout(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(190, 0));
        sidebar.setOpaque(false);  // let paintComponent do the drawing

        // Logo section
        JPanel logoPanel = new JPanel();
        logoPanel.setOpaque(false);
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setBorder(new EmptyBorder(25, 0, 20, 0));

        JLabel iconLbl = new JLabel("🏨", SwingConstants.CENTER);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        iconLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLbl = new JLabel("Hotel Management", SwingConstants.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(Color.WHITE);
        titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLbl = new JLabel("System", SwingConstants.CENTER);
        subtitleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        subtitleLbl.setForeground(Color.WHITE);
        subtitleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        logoPanel.add(iconLbl);
        logoPanel.add(Box.createVerticalStrut(8));
        logoPanel.add(titleLbl);
        logoPanel.add(subtitleLbl);

        // Nav menu
        JPanel navPanel = new JPanel();
        navPanel.setOpaque(false);
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[][] navItems = {
            {"🏠", "Dashboard"},
            {"🛏", "Rooms"},
            {"👤", "Customers"},
            {"📋", "Bookings"},
            {"📊", "Reports"}
        };

        ButtonGroup bg = new ButtonGroup();
        JToggleButton[] navBtns = new JToggleButton[navItems.length];
        for (int i = 0; i < navItems.length; i++) {
            final int idx = i;
            navBtns[i] = createNavButton(navItems[i][0], navItems[i][1]);
            bg.add(navBtns[i]);
            navPanel.add(navBtns[i]);
            navPanel.add(Box.createVerticalStrut(4));
            navBtns[i].addActionListener(e -> switchPanel(navItems[idx][1]));
        }
        navBtns[0].setSelected(true);

        // Exit button at bottom
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBorder(new EmptyBorder(0, 10, 15, 10));

        JButton exitBtn = new JButton("⏻  Exit");
        styleNavPlain(exitBtn);
        exitBtn.addActionListener(e -> System.exit(0));
        bottomPanel.add(exitBtn);

        // Admin badge
        JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        adminPanel.setOpaque(false);
        JLabel avatar = new JLabel("👤");
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        JPanel adminInfo = new JPanel();
        adminInfo.setOpaque(false);
        adminInfo.setLayout(new BoxLayout(adminInfo, BoxLayout.Y_AXIS));
        JLabel adminName = new JLabel("Admin");
        adminName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        adminName.setForeground(Color.WHITE);
        JLabel adminRole = new JLabel("Administrator");
        adminRole.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        adminRole.setForeground(new Color(180, 210, 255));
        adminInfo.add(adminName);
        adminInfo.add(adminRole);
        adminPanel.add(avatar);
        adminPanel.add(adminInfo);

        sidebar.add(logoPanel, BorderLayout.NORTH);
        sidebar.add(navPanel, BorderLayout.CENTER);

        JPanel sideBottom = new JPanel();
        sideBottom.setOpaque(false);
        sideBottom.setLayout(new BoxLayout(sideBottom, BoxLayout.Y_AXIS));
        sideBottom.add(bottomPanel);
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(255, 255, 255, 60));
        sideBottom.add(sep);
        sideBottom.add(adminPanel);
        sidebar.add(sideBottom, BorderLayout.SOUTH);

        return sidebar;
    }

    static JToggleButton createNavButton(String icon, String text) {
        JToggleButton btn = new JToggleButton(icon + "  " + text) {
            @Override protected void paintComponent(Graphics g) {
                if (isSelected()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(new Color(21, 101, 192, 200));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                    g2.dispose();
                }
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(new Color(190, 215, 255));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(8, 14, 8, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);

        btn.addItemListener(e -> {
            if (btn.isSelected()) {
                btn.setForeground(Color.WHITE);
                btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            } else {
                btn.setForeground(new Color(190, 215, 255));
                btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            }
        });
        return btn;
    }

    static void styleNavPlain(JButton btn) {
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(new Color(190, 215, 255));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(8, 14, 8, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
    }

    // ─── MAIN CONTENT AREA ──────────────────────────────────────────────────────
    static JPanel buildMainArea() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(255, 255, 255, 230));
        topBar.setBorder(new EmptyBorder(12, 20, 12, 20));
        topBar.setOpaque(true);

        JLabel hamburger = new JLabel("≡");
        hamburger.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        hamburger.setForeground(TEXT_DARK);

        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightBar.setOpaque(false);

        JLabel calIcon = new JLabel("📅");
        calIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        dateLabel = new JLabel();
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        dateLabel.setForeground(TEXT_DARK);

        JLabel clockIcon = new JLabel("🕐");
        clockIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        timeLabel.setForeground(TEXT_DARK);

        rightBar.add(calIcon); rightBar.add(dateLabel);
        rightBar.add(Box.createHorizontalStrut(10));
        rightBar.add(clockIcon); rightBar.add(timeLabel);

        topBar.add(hamburger, BorderLayout.WEST);
        topBar.add(rightBar, BorderLayout.EAST);

        // Card layout for pages
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false);

        dashboardPanel = buildDashboard();
        contentPanel.add(dashboardPanel, "Dashboard");
        contentPanel.add(buildBookingsPage(), "Bookings");
        contentPanel.add(buildRoomsPage(), "Rooms");
        contentPanel.add(buildCustomersPage(), "Customers");
        contentPanel.add(buildSimplePage("🏨", "Hotels", "Manage hotel properties here."), "Hotels");
        reportsPanel = buildReportsPage();
        contentPanel.add(reportsPanel, "Reports");

        wrapper.add(topBar, BorderLayout.NORTH);
        wrapper.add(contentPanel, BorderLayout.CENTER);
        return wrapper;
    }

    static void switchPanel(String name) {
        if ("Reports".equals(name)) refreshReportsPage();
        if ("Dashboard".equals(name)) refreshDashboard();
        cardLayout.show(contentPanel, name);
    }

    static void refreshReportsPage() {
        if (reportsPanel != null) {
            contentPanel.remove(reportsPanel);
            reportsPanel = buildReportsPage();
            contentPanel.add(reportsPanel, "Reports");
        }
    }

    static void refreshDashboard() {
        if (dashboardPanel != null) {
            contentPanel.remove(dashboardPanel);
            dashboardPanel = buildDashboard();
            contentPanel.add(dashboardPanel, "Dashboard");
        }
    }

    static void updateClock() {
        SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH);
        SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm a");
        java.util.Date now = new java.util.Date();
        if (dateLabel != null) dateLabel.setText(dateFmt.format(now));
        if (timeLabel != null) timeLabel.setText(timeFmt.format(now));
    }

    // ─── DASHBOARD ──────────────────────────────────────────────────────────────
    static JPanel buildDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Dashboard");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(0, 0, 16, 0));

        // Stats row — FIX: was only 3 cards in a GridLayout(1,4), added 4th card
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 0));
        statsRow.setOpaque(false);
        statsRow.add(buildStatCard("🛏", "Total Rooms",    String.valueOf(hotel.viewTotalRooms().size()),    ACCENT_GREEN,  new Color(232, 245, 233)));
        statsRow.add(buildStatCard("✅", "Available",      String.valueOf(hotel.viewAvailableRooms().size()), ACCENT_BLUE,   new Color(227, 242, 253)));
        statsRow.add(buildStatCard("📋", "Total Bookings", String.valueOf(hotel.getBookings().size()),        ACCENT_PURPLE, new Color(243, 229, 245)));
        statsRow.add(buildStatCard("💰", "Revenue",        "$" + String.format("%.0f", hotel.getBookings().stream().mapToDouble(Booking::getTotalBill).sum()), ACCENT_ORANGE, new Color(255, 243, 224)));

        // Room availability row
        JPanel roomAvailRow = new JPanel(new GridLayout(1, 2, 14, 0));
        roomAvailRow.setOpaque(false);
        java.util.List<Room> availableRooms = hotel.viewAvailableRooms();
        java.util.List<Room> totalRooms = hotel.viewTotalRooms();
        java.util.List<Room> unavailableRooms = new java.util.ArrayList<>();
        for (Room r : totalRooms) {
            if (!r.isAvailable()) unavailableRooms.add(r);
        }
        roomAvailRow.add(buildRoomListCard("Available Rooms", availableRooms, ACCENT_GREEN));
        roomAvailRow.add(buildRoomListCard("Unavailable Rooms", unavailableRooms, ACCENT_ORANGE));

        // Middle row
        JPanel midRow = new JPanel(new GridLayout(1, 2, 14, 0));
        midRow.setOpaque(false);

        // Recent Bookings table
        String[] bookCols = {"Booking ID", "Customer", "Room", "Check In", "Check Out", "Status"};
        DefaultTableModel bookModel = new DefaultTableModel(bookCols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Booking b : hotel.getBookings()) {
            bookModel.addRow(new Object[]{
                "B00" + b.getBookingId(),
                b.getCustomer().getName(),
                b.getRoom().getRoomNo(),
                "—", "—", "Confirmed"
            });
        }
        midRow.add(buildTableCard("Recent Bookings", bookModel, new int[]{5}, CONFIRMED_CLR));

        // Donut chart
        JPanel chartCard = buildCard("Room Status");
        int available = (int) hotel.viewTotalRooms().stream().filter(Room::isAvailable).count();
        int occupied  = hotel.viewTotalRooms().size() - available;
        chartCard.add(new DonutChart(available, occupied), BorderLayout.CENTER);
        midRow.add(chartCard);

        // Bottom row
        JPanel botRow = new JPanel(new GridLayout(1, 3, 14, 0));
        botRow.setOpaque(false);

        String[] roomCols = {"Room No", "Type", "Price/Day", "Status"};
        DefaultTableModel roomModel = new DefaultTableModel(roomCols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Room r : hotel.viewTotalRooms()) {
            roomModel.addRow(new Object[]{
                r.getRoomNo(), r.getType(), "$" + r.getPricePerDay(),
                r.isAvailable() ? "Available" : "Occupied"
            });
        }
        botRow.add(buildTableCard("Rooms", roomModel, new int[]{3},
            (ColorMapper) row -> ((String) row[3]).equals("Available") ? ACCENT_GREEN : ACCENT_ORANGE));

        // Quick Actions
        JPanel qaCard = buildCard("Quick Actions");
        JPanel qaBtns = new JPanel(new GridLayout(2, 2, 10, 10));
        qaBtns.setOpaque(false);
        qaBtns.setBorder(new EmptyBorder(10, 10, 10, 10));
        qaBtns.add(buildQuickBtn("🏨", "Add Hotel",    ACCENT_BLUE,   () -> showAddHotelDialog()));
        qaBtns.add(buildQuickBtn("🛏", "Add Room",     ACCENT_GREEN,  () -> showAddRoomDialog()));
        qaBtns.add(buildQuickBtn("👤", "Add Customer", ACCENT_ORANGE, () -> showAddCustomerDialog()));
        qaBtns.add(buildQuickBtn("📋", "New Booking",  ACCENT_PURPLE, () -> showBookRoomDialog()));
        qaCard.add(qaBtns, BorderLayout.CENTER);
        botRow.add(qaCard);

        // Checkout card
        JPanel coCard = buildCard("Checkout");
        coCard.add(buildCheckoutForm(), BorderLayout.CENTER);
        botRow.add(coCard);

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);
        center.add(statsRow);
        center.add(Box.createVerticalStrut(14));
        center.add(roomAvailRow);
        center.add(Box.createVerticalStrut(14));
        center.add(midRow);
        center.add(Box.createVerticalStrut(14));
        center.add(botRow);

        JScrollPane scroll = new JScrollPane(center);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);

        panel.add(title, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // ─── BOOKINGS PAGE ──────────────────────────────────────────────────────────
    static JPanel buildBookingsPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Bookings");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(new Color(255, 255, 255, 230));
        formCard.setOpaque(true);
        formCard.setBorder(new EmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // FIX: placeholder text stored separately so fields start empty
        JTextField fName  = styledField("Customer Name");
        JTextField fId    = styledField("Customer ID");
        JTextField fPhone = styledField("Phone");
        JTextField fRoom  = styledField("Room No");
        JTextField fDays  = styledField("Days");

        // Meal service
        String[] mealTypes = {"None", "Breakfast", "Lunch", "Dinner"};
        JComboBox<String> mealTypeBox = new JComboBox<>(mealTypes);
        JComboBox<String> mealItemBox = new JComboBox<>();

        String[] breakfast = {"Tea+Paratha (200)", "Omelette (250)"};
        String[] lunch     = {"Biryani (350)", "Daal Chawal (200)"};
        String[] dinner    = {"BBQ (800)", "Karahi (600)"};

        mealTypeBox.addActionListener(e -> {
            mealItemBox.removeAllItems();
            String type = (String) mealTypeBox.getSelectedItem();
            if ("Breakfast".equals(type))
                for (String i : breakfast) mealItemBox.addItem(i);
            else if ("Lunch".equals(type))
                for (String i : lunch) mealItemBox.addItem(i);
            else if ("Dinner".equals(type))
                for (String i : dinner) mealItemBox.addItem(i);
        });

        String[] roomServices  = {"None", "Cleaning (300)", "Extra Bed (500)", "AC Service (400)"};
        JComboBox<String> roomServiceBox = new JComboBox<>(roomServices);

        String[] laundryServices = {"None", "Wash (200)", "Iron (150)", "Full Laundry (400)"};
        JComboBox<String> laundryBox = new JComboBox<>(laundryServices);

        JTextArea fOut = new JTextArea(5, 20);
        fOut.setEditable(false);
        fOut.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        fOut.setBackground(new Color(248, 249, 252));

        addRow(formCard, gbc, 0, "Name:",         fName);
        addRow(formCard, gbc, 1, "ID:",            fId);
        addRow(formCard, gbc, 2, "Phone:",         fPhone);
        addRow(formCard, gbc, 3, "Room:",          fRoom);
        addRow(formCard, gbc, 4, "Days:",          fDays);
        addRow(formCard, gbc, 5, "Meal Type:",     mealTypeBox);
        addRow(formCard, gbc, 6, "Meal Item:",     mealItemBox);
        addRow(formCard, gbc, 7, "Room Service:",  roomServiceBox);
        addRow(formCard, gbc, 8, "Laundry:",       laundryBox);

        JButton bookBtn  = accentButton("Book Room",     ACCENT_BLUE);
        JButton printBtn = accentButton("Print Receipt", ACCENT_GREEN);

        bookBtn.addActionListener(e -> {
            try {
                // FIX: guard against placeholder values still in fields
                String nameVal  = getFieldValue(fName,  "Customer Name");
                String idVal    = getFieldValue(fId,    "Customer ID");
                String phoneVal = getFieldValue(fPhone, "Phone");
                String roomVal  = getFieldValue(fRoom,  "Room No");
                String daysVal  = getFieldValue(fDays,  "Days");

                if (nameVal.isEmpty() || idVal.isEmpty() || phoneVal.isEmpty()
                        || roomVal.isEmpty() || daysVal.isEmpty()) {
                    fOut.setText("❌ Please fill all required fields.");
                    return;
                }

                Customer c = new Customer(nameVal, idVal, phoneVal);
                int roomNo = Integer.parseInt(roomVal);
                int days   = Integer.parseInt(daysVal);

                double mealPrice        = extractPrice((String) mealItemBox.getSelectedItem());
                double roomServicePrice = extractPrice((String) roomServiceBox.getSelectedItem());
                double laundryPrice     = extractPrice((String) laundryBox.getSelectedItem());
                double extra = mealPrice + roomServicePrice + laundryPrice;

                Booking b = hotel.bookRoom(roomNo, c, days, extra);

                if (b != null) {
                    int bookingId = bookingCounter++;
                    double total = b.getTotalBill();
                    fOut.setText(
                        "🎉 BOOKING SUCCESSFUL!\n\n" +
                        "🆔 Booking ID: B" + bookingId + "\n" +
                        "Customer: " + c.getName() + "\n" +
                        "Room: " + roomNo + "\n" +
                        "Days: " + days + "\n" +
                        "Meal: " + mealItemBox.getSelectedItem() + "\n" +
                        "Room Service: " + roomServiceBox.getSelectedItem() + "\n" +
                        "Laundry: " + laundryBox.getSelectedItem() + "\n\n" +
                        "💰 Total Bill: " + String.format("%.2f", total) + " Rs"
                    );
                    // Clear fields after success
                    clearField(fName, "Customer Name");
                    clearField(fId, "Customer ID");
                    clearField(fPhone, "Phone");
                    clearField(fRoom, "Room No");
                    clearField(fDays, "Days");
                } else {
                    fOut.setText("❌ Room " + roomNo + " not available or does not exist!");
                }
            } catch (NumberFormatException ex) {
                fOut.setText("❌ Room No and Days must be numbers.");
            } catch (Exception ex) {
                fOut.setText("❌ Error: " + ex.getMessage());
            }
        });

        printBtn.addActionListener(e -> {
            try {
                if (fOut.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "❌ Nothing to print!");
                    return;
                }
                boolean done = fOut.print();
                JOptionPane.showMessageDialog(null, done ? "✅ Printed Successfully!" : "❌ Cancelled!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ " + ex.getMessage());
            }
        });

        gbc.gridx = 1; gbc.gridy = 9;
        formCard.add(bookBtn, gbc);
        gbc.gridx = 1; gbc.gridy = 10;
        formCard.add(printBtn, gbc);
        gbc.gridx = 0; gbc.gridy = 11; gbc.gridwidth = 2;
        formCard.add(new JScrollPane(fOut), gbc);

        panel.add(title, BorderLayout.NORTH);
        panel.add(new JScrollPane(formCard), BorderLayout.CENTER);
        return panel;
    }

    /** Returns the field value, treating placeholder text as empty */
    static String getFieldValue(JTextField field, String placeholder) {
        String val = field.getText().trim();
        return val.equals(placeholder) ? "" : val;
    }

    /** Resets a field back to placeholder state */
    static void clearField(JTextField field, String placeholder) {
        field.setText(placeholder);
        field.setForeground(Color.GRAY);
    }

    static double extractPrice(String text) {
        if (text == null || !text.contains("(")) return 0;
        try {
            return Double.parseDouble(text.substring(text.indexOf('(') + 1, text.indexOf(')')));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ─── ROOMS PAGE ─────────────────────────────────────────────────────────────
    static JPanel buildRoomsPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Rooms");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(0, 0, 16, 0));

        // FIX: added "Book" value in refreshRoomModel and proper column count
        String[] cols = {"Room No", "Type", "Price/Day", "Status", "Action"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 4; }
        };

        JTable table = new JTable(model);
        table.setRowHeight(32);

        refreshRoomModel(model);

        table.getColumn("Action").setCellRenderer((t, v, s, f, r, c) -> {
            JButton btn = new JButton("Book");
            btn.setBackground(ACCENT_BLUE);
            btn.setForeground(Color.WHITE);
            btn.setOpaque(true);
            return btn;
        });

        table.getColumn("Action").setCellEditor(new DefaultCellEditor(new JTextField()) {
            JButton btn = new JButton("Book");
            int selectedRow;
            {
                btn.setBackground(ACCENT_BLUE);
                btn.setForeground(Color.WHITE);
                btn.setOpaque(true);
                btn.addActionListener(e -> {
                    Object val = model.getValueAt(selectedRow, 0);
                    if (val != null) {
                        openBookingWithRoom((int) val);
                    }
                    fireEditingStopped();
                });
            }
            public Component getTableCellEditorComponent(JTable tbl, Object value,
                    boolean isSelected, int row, int col) {
                selectedRow = row;
                return btn;
            }
            public Object getCellEditorValue() { return "Book"; }
        });

        JButton refreshBtn = accentButton("Refresh", ACCENT_BLUE);
        refreshBtn.addActionListener(e -> refreshRoomModel(model));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        top.setOpaque(false);
        top.add(refreshBtn);

        JPanel cardWrapper = new JPanel(new BorderLayout());
        cardWrapper.setBackground(new Color(255, 255, 255, 220));
        cardWrapper.setOpaque(true);
        cardWrapper.setBorder(new EmptyBorder(10, 10, 10, 10));
        cardWrapper.add(top, BorderLayout.NORTH);
        cardWrapper.add(new JScrollPane(table), BorderLayout.CENTER);

        panel.add(title, BorderLayout.NORTH);
        panel.add(cardWrapper, BorderLayout.CENTER);
        return panel;
    }

    static void refreshRoomModel(DefaultTableModel model) {
        model.setRowCount(0);
        for (Room r : hotel.viewTotalRooms()) {
            // FIX: added "Book" value as 5th column so editor/renderer works
            model.addRow(new Object[]{
                r.getRoomNo(), r.getType(), "$" + r.getPricePerDay(),
                r.isAvailable() ? "Available" : "Occupied",
                "Book"
            });
        }
    }

    // ─── CUSTOMERS PAGE ─────────────────────────────────────────────────────────
    static JPanel buildCustomersPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Customers");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(0, 0, 16, 0));

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(new Color(255, 255, 255, 230));
        formCard.setOpaque(true);
        formCard.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 225, 235), 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField fName  = styledField("Full Name");
        JTextField fId    = styledField("Customer ID");
        JTextField fPhone = styledField("Phone Number");
        JTextArea  fOut   = new JTextArea(3, 20);
        fOut.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        fOut.setEditable(false);
        fOut.setBackground(new Color(248, 249, 252));

        addRow(formCard, gbc, 0, "Full Name:",   fName);
        addRow(formCard, gbc, 1, "Customer ID:", fId);
        addRow(formCard, gbc, 2, "Phone:",       fPhone);

        JButton addBtn = accentButton("Add Customer", ACCENT_ORANGE);
        addBtn.addActionListener(e -> {
            try {
                String nameVal  = getFieldValue(fName,  "Full Name");
                String idVal    = getFieldValue(fId,    "Customer ID");
                String phoneVal = getFieldValue(fPhone, "Phone Number");
                if (nameVal.isEmpty() || idVal.isEmpty() || phoneVal.isEmpty()) {
                    fOut.setText("❌ Please fill all fields.");
                    return;
                }
                Customer c = new Customer(nameVal, idVal, phoneVal);
                fOut.setText("✅ Customer added:\n" + c.getDetails());
                clearField(fName, "Full Name");
                clearField(fId, "Customer ID");
                clearField(fPhone, "Phone Number");
            } catch (Exception ex) {
                fOut.setText("❌ " + ex.getMessage());
            }
        });

        gbc.gridx = 1; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST;
        formCard.add(addBtn, gbc);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.BOTH;
        formCard.add(new JScrollPane(fOut), gbc);

        panel.add(title, BorderLayout.NORTH);
        panel.add(new JScrollPane(formCard), BorderLayout.CENTER);
        return panel;
    }

    // ─── REPORTS PAGE ───────────────────────────────────────────────────────────
    static JPanel buildReportsPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Reports");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(0, 0, 16, 0));

        int totalRooms     = hotel.viewTotalRooms().size();
        int availableRooms = hotel.viewAvailableRooms().size();
        int occupiedRooms  = totalRooms - availableRooms;
        int totalBookings  = hotel.getBookings().size();
        double totalRevenue = hotel.getBookings().stream()
            .mapToDouble(Booking::getTotalBill).sum();

        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 0));
        statsRow.setOpaque(false);
        statsRow.add(buildStatCard("🏨", "Total Rooms",  String.valueOf(totalRooms),     ACCENT_BLUE,   new Color(227, 242, 253)));
        statsRow.add(buildStatCard("✅", "Available",    String.valueOf(availableRooms), ACCENT_GREEN,  new Color(232, 245, 233)));
        statsRow.add(buildStatCard("⛔", "Occupied",     String.valueOf(occupiedRooms),  ACCENT_ORANGE, new Color(255, 243, 224)));
        statsRow.add(buildStatCard("📋", "Bookings",     String.valueOf(totalBookings),  ACCENT_PURPLE, new Color(243, 229, 245)));

        JPanel hotelDetails = buildCard("Hotel Details");
        JPanel detailsBody = new JPanel();
        detailsBody.setOpaque(false);
        detailsBody.setLayout(new BoxLayout(detailsBody, BoxLayout.Y_AXIS));
        detailsBody.setBorder(new EmptyBorder(10, 0, 0, 0));
        detailsBody.add(createInfoLine("Hotel Name:",      hotel.getName() != null ? hotel.getName() : "N/A"));
        detailsBody.add(createInfoLine("Location:",        hotel.getLocation() != null ? hotel.getLocation() : "N/A"));
        detailsBody.add(createInfoLine("Contact:",         hotel.getContact() != null ? hotel.getContact() : "N/A"));
        detailsBody.add(createInfoLine("Total Rooms:",     String.valueOf(totalRooms)));
        detailsBody.add(createInfoLine("Available Rooms:", String.valueOf(availableRooms)));
        detailsBody.add(createInfoLine("Occupied Rooms:",  String.valueOf(occupiedRooms)));
        detailsBody.add(createInfoLine("Total Bookings:",  String.valueOf(totalBookings)));
        detailsBody.add(createInfoLine("Total Revenue:",   "$" + String.format("%.2f", totalRevenue)));
        hotelDetails.add(detailsBody, BorderLayout.CENTER);

        String[] cols = {"Booking ID", "Customer", "Room", "Days", "Total Bill"};
        DefaultTableModel bookingModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Booking b : hotel.getBookings()) {
            bookingModel.addRow(new Object[]{
                "B00" + b.getBookingId(),
                b.getCustomer().getName(),
                b.getRoom().getRoomNo(),
                b.getDays(),
                String.format("$%.2f", b.getTotalBill())
            });
        }
        JPanel tableCard = buildTableCard("Saved Bookings", bookingModel, new int[]{4}, CONFIRMED_CLR);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.add(statsRow);
        center.add(Box.createVerticalStrut(14));
        center.add(hotelDetails);
        center.add(Box.createVerticalStrut(14));
        center.add(tableCard);

        panel.add(title, BorderLayout.NORTH);
        panel.add(new JScrollPane(center), BorderLayout.CENTER);
        return panel;
    }

    static JPanel createInfoLine(String label, String value) {
        JPanel line = new JPanel(new BorderLayout());
        line.setOpaque(false);
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(TEXT_DARK);
        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        v.setForeground(TEXT_GRAY);
        line.add(l, BorderLayout.WEST);
        line.add(v, BorderLayout.EAST);
        line.setBorder(new EmptyBorder(4, 0, 4, 0));
        return line;
    }

    // ─── SIMPLE PAGE ────────────────────────────────────────────────────────────
    static JPanel buildSimplePage(String icon, String name, String msg) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(40, 40, 40, 40));

        JLabel lbl = new JLabel(icon + "  " + name, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lbl.setForeground(Color.WHITE);

        JLabel sub = new JLabel("<html><center>" + msg.replace("\n", "<br>") + "</center></html>", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        sub.setForeground(new Color(200, 220, 255));

        panel.add(lbl, BorderLayout.CENTER);
        panel.add(sub, BorderLayout.SOUTH);
        return panel;
    }

    // ─── DIALOGS ────────────────────────────────────────────────────────────────
    static void showAddHotelDialog() {
        JTextField name = styledField("Hotel Name");
        JTextField loc  = styledField("Location");
        JTextField cont = styledField("Contact Number");
        JPanel p = new JPanel(new GridLayout(3, 2, 8, 8));
        p.add(new JLabel("Hotel Name:")); p.add(name);
        p.add(new JLabel("Location:"));  p.add(loc);
        p.add(new JLabel("Contact:"));   p.add(cont);
        int res = JOptionPane.showConfirmDialog(null, p, "Add Hotel", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            hotel.setName(name.getText());
            hotel.setLocation(loc.getText());
            hotel.setContact(cont.getText());
            JOptionPane.showMessageDialog(null, "✅ Hotel details updated!");
        }
    }

    static void showAddRoomDialog() {
        JTextField rno   = styledField("e.g. 106");
        JTextField type  = styledField("Single / Double / Suite");
        JTextField price = styledField("e.g. 120.0");
        JPanel p = new JPanel(new GridLayout(3, 2, 8, 8));
        p.add(new JLabel("Room No:"));   p.add(rno);
        p.add(new JLabel("Type:"));      p.add(type);
        p.add(new JLabel("Price/Day:")); p.add(price);
        int res = JOptionPane.showConfirmDialog(null, p, "Add Room", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            try {
                hotel.addRoom(new Room(
                    Integer.parseInt(rno.getText()),
                    type.getText(),
                    Double.parseDouble(price.getText())
                ));
                JOptionPane.showMessageDialog(null, "✅ Room added!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ " + ex.getMessage());
            }
        }
    }

    static void openBookingWithRoom(int roomNo) {
        cardLayout.show(contentPanel, "Bookings");
        JOptionPane.showMessageDialog(null, "Room " + roomNo + " selected — fill in customer details to confirm.");
    }

    static void showAddCustomerDialog() {
        JTextField name  = styledField("Full Name");
        JTextField id    = styledField("Customer ID");
        JTextField phone = styledField("Phone");
        JPanel p = new JPanel(new GridLayout(3, 2, 8, 8));
        p.add(new JLabel("Name:"));  p.add(name);
        p.add(new JLabel("ID:"));    p.add(id);
        p.add(new JLabel("Phone:")); p.add(phone);
        int res = JOptionPane.showConfirmDialog(null, p, "Add Customer", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            try {
                new Customer(name.getText(), id.getText(), phone.getText());
                JOptionPane.showMessageDialog(null, "✅ Customer added!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ " + ex.getMessage());
            }
        }
    }

    static void showBookRoomDialog() {
        JTextField fName  = styledField("Customer Name");
        JTextField fId    = styledField("Customer ID");
        JTextField fPhone = styledField("Phone");
        JTextField fRoom  = styledField("Room No");
        JTextField fDays  = styledField("Days");
        JTextField fMeal  = styledField("Meal Charges (e.g. 0)");
        JPanel p = new JPanel(new GridLayout(6, 2, 8, 8));
        p.add(new JLabel("Name:"));    p.add(fName);
        p.add(new JLabel("ID:"));      p.add(fId);
        p.add(new JLabel("Phone:"));   p.add(fPhone);
        p.add(new JLabel("Room No:")); p.add(fRoom);
        p.add(new JLabel("Days:"));    p.add(fDays);
        p.add(new JLabel("Meal:"));    p.add(fMeal);
        int res = JOptionPane.showConfirmDialog(null, p, "New Booking", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            try {
                Customer c = new Customer(fName.getText(), fId.getText(), fPhone.getText());
                Booking b = hotel.bookRoom(
                    Integer.parseInt(fRoom.getText()), c,
                    Integer.parseInt(fDays.getText()),
                    Double.parseDouble(fMeal.getText().isEmpty() ? "0" : fMeal.getText())
                );
                JOptionPane.showMessageDialog(null, b != null ? "✅ " + b : "❌ Room unavailable.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ " + ex.getMessage());
            }
        }
    }

    // ─── CHECKOUT FORM ──────────────────────────────────────────────────────────
    static JPanel buildCheckoutForm() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTextField fRoom = styledField("Enter Room Number");

        JTextArea fOut = new JTextArea(3, 15);
        fOut.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        fOut.setEditable(false);
        fOut.setBackground(new Color(248, 249, 252));

        JButton btn = accentButton("Checkout", new Color(244, 67, 54));
        btn.addActionListener(e -> {
            try {
                String roomStr = getFieldValue(fRoom, "Enter Room Number");
                if (roomStr.isEmpty()) {
                    fOut.setText("❌ Enter a room number.");
                    return;
                }
                int roomNo = Integer.parseInt(roomStr);
                boolean found = false;
                for (Booking b : hotel.getBookings()) {
                    if (b.getRoom().getRoomNo() == roomNo) {
                        hotel.checkOut(b.getBookingId());
                        found = true;
                        break;
                    }
                }
                fOut.setText(found
                    ? "✅ Room " + roomNo + " checked out successfully!"
                    : "❌ Room not found in bookings!");
            } catch (NumberFormatException ex) {
                fOut.setText("❌ Enter a valid room number!");
            }
        });

        JPanel top = new JPanel(new BorderLayout(6, 0));
        top.setOpaque(false);
        top.add(fRoom, BorderLayout.CENTER);
        top.add(btn, BorderLayout.EAST);

        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(fOut), BorderLayout.CENTER);
        return p;
    }

    // ─── HELPERS ────────────────────────────────────────────────────────────────
    interface ColorMapper { Color map(Object[] row); }

    static JPanel buildStatCard(String icon, String label, String value, Color accent, Color bg) {
        JPanel card = new JPanel(new BorderLayout(10, 0));
        card.setBackground(bg);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 225, 235), 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        iconLbl.setPreferredSize(new Dimension(50, 50));
        iconLbl.setOpaque(true);
        iconLbl.setBackground(accent.brighter());

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        JLabel valLbl = new JLabel(value);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        valLbl.setForeground(TEXT_DARK);
        JLabel lblLbl = new JLabel(label);
        lblLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblLbl.setForeground(TEXT_GRAY);
        info.add(valLbl);
        info.add(lblLbl);

        card.add(iconLbl, BorderLayout.WEST);
        card.add(info, BorderLayout.CENTER);
        return card;
    }

    static JPanel buildRoomListCard(String title, java.util.List<Room> rooms, Color accent) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD_BG);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 225, 235), 1, true),
            new EmptyBorder(14, 14, 14, 14)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(TEXT_DARK);
        titleLbl.setBorder(new EmptyBorder(0, 0, 10, 0));
        card.add(titleLbl, BorderLayout.NORTH);

        JPanel listPanel = new JPanel();
        listPanel.setOpaque(false);
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));

        if (rooms.isEmpty()) {
            JLabel noRooms = new JLabel("No rooms");
            noRooms.setFont(new Font("Segoe UI", Font.ITALIC, 12));
            noRooms.setForeground(TEXT_GRAY);
            listPanel.add(noRooms);
        } else {
            for (Room r : rooms) {
                JPanel roomItem = new JPanel(new BorderLayout());
                roomItem.setOpaque(false);
                roomItem.setBorder(new EmptyBorder(2, 0, 2, 0));
                JLabel roomNo = new JLabel("Room " + r.getRoomNo());
                roomNo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                roomNo.setForeground(TEXT_DARK);
                JLabel roomType = new JLabel(r.getType() + " - $" + r.getPricePerDay());
                roomType.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                roomType.setForeground(TEXT_GRAY);
                roomItem.add(roomNo, BorderLayout.WEST);
                roomItem.add(roomType, BorderLayout.EAST);
                listPanel.add(roomItem);
            }
        }

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    static JPanel buildCard(String title) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD_BG);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 225, 235), 1, true),
            new EmptyBorder(14, 14, 14, 14)
        ));
        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(TEXT_DARK);
        titleLbl.setBorder(new EmptyBorder(0, 0, 10, 0));
        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    @SuppressWarnings("unchecked")
    static JPanel buildTableCard(String title, DefaultTableModel model, int[] statusCols, Object colorArg) {
        JPanel card = buildCard(title);
        JTable table = styledTable(model);
        if (colorArg instanceof Color c) {
            for (int col : statusCols) colorStatusColumnSingle(table, col, c);
        } else if (colorArg instanceof ColorMapper cm) {
            colorStatusColumnMapper(table, statusCols[0], cm, model);
        }
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        return card;
    }

    static JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        t.setRowHeight(28);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.getTableHeader().setBackground(new Color(245, 247, 252));
        t.getTableHeader().setForeground(TEXT_GRAY);
        t.setSelectionBackground(new Color(227, 242, 253));
        t.setSelectionForeground(TEXT_DARK);
        t.setFillsViewportHeight(true);
        return t;
    }

    static void colorStatusColumnSingle(JTable t, int col, Color c) {
        t.getColumnModel().getColumn(col).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean sel, boolean foc, int row, int column) {
                super.getTableCellRendererComponent(table, value, sel, foc, row, column);
                setForeground(c);
                setFont(new Font("Segoe UI", Font.BOLD, 12));
                return this;
            }
        });
    }

    static void colorStatusColumnMapper(JTable t, int col, ColorMapper cm, DefaultTableModel model) {
        t.getColumnModel().getColumn(col).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean sel, boolean foc, int row, int column) {
                super.getTableCellRendererComponent(table, value, sel, foc, row, column);
                if (row < model.getRowCount()) {
                    Object[] rowData = new Object[model.getColumnCount()];
                    for (int i = 0; i < model.getColumnCount(); i++) rowData[i] = model.getValueAt(row, i);
                    setForeground(cm.map(rowData));
                }
                setFont(new Font("Segoe UI", Font.BOLD, 12));
                return this;
            }
        });
    }

    static JButton buildQuickBtn(String icon, String label, Color color, Runnable action) {
        JButton btn = new JButton("<html><center>" + icon + "<br><font size='3'>" + label + "</font></center></html>");
        btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        btn.setForeground(color);
        btn.setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), 20));
        btn.setBorder(new LineBorder(new Color(color.getRed(), color.getGreen(), color.getBlue(), 80), 1, true));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.addActionListener(e -> action.run());
        return btn;
    }

    static JTextField styledField(String placeholder) {
        JTextField f = new JTextField(15);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBorder(new CompoundBorder(
            new LineBorder(new Color(200, 210, 230), 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        f.setForeground(Color.GRAY);
        f.setText(placeholder);
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (f.getText().equals(placeholder)) { f.setText(""); f.setForeground(TEXT_DARK); }
            }
            public void focusLost(FocusEvent e) {
                if (f.getText().isEmpty()) { f.setText(placeholder); f.setForeground(Color.GRAY); }
            }
        });
        return f;
    }

    static JButton accentButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setBorder(new EmptyBorder(8, 18, 8, 18));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        return btn;
    }

    static void addRow(JPanel panel, GridBagConstraints gbc, int row, String labelText, JComponent field) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1; gbc.weightx = 0;
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl.setForeground(TEXT_DARK);
        panel.add(lbl, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        panel.add(field, gbc);
    }

    // ─── DONUT CHART ─────────────────────────────────────────────────────────────
    static class DonutChart extends JPanel {
        int available, occupied;
        DonutChart(int a, int o) {
            this.available = a; this.occupied = o;
            setOpaque(false);
            setPreferredSize(new Dimension(160, 160));
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int total = available + occupied;
            int w = getWidth(), h = getHeight();
            int sz = Math.min(w, h) - 20;
            int x = (w - sz) / 2, y = (h - sz) / 2;
            if (total == 0) {
                g2.setColor(Color.LIGHT_GRAY);
                g2.fillOval(x, y, sz, sz);
            } else {
                double avAngle = 360.0 * available / total;
                g2.setColor(ACCENT_GREEN);
                g2.fillArc(x, y, sz, sz, 90, -(int) avAngle);
                g2.setColor(ACCENT_BLUE);
                g2.fillArc(x, y, sz, sz, (int)(90 - avAngle), -(360 - (int) avAngle));
            }
            int hole = sz / 3;
            g2.setColor(CARD_BG);
            g2.fillOval(x + hole, y + hole, sz - 2 * hole, sz - 2 * hole);

            g2.setColor(TEXT_DARK);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2.drawString(String.valueOf(available), x + sz/2 - 22, y + sz/2 + 5);
            g2.setColor(ACCENT_BLUE);
            g2.drawString(String.valueOf(occupied), x + sz/2 + 8, y + sz/2 + 5);

            int ly = y + sz + 10;
            g2.setColor(ACCENT_GREEN);
            g2.fillRect(x, ly, 12, 12);
            g2.setColor(TEXT_DARK);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            g2.drawString("Available (" + available + ")", x + 16, ly + 11);
            g2.setColor(ACCENT_BLUE);
            g2.fillRect(x + sz/2, ly, 12, 12);
            g2.setColor(TEXT_DARK);
            g2.drawString("Occupied (" + occupied + ")", x + sz/2 + 16, ly + 11);
        }
    }
}
