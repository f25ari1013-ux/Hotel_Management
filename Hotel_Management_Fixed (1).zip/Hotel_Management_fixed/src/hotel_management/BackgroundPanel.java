package hotel_management;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 * BackgroundPanel - renders a scaled, full-coverage background image
 * behind the entire application window.
 */
public class BackgroundPanel extends JPanel {

    private BufferedImage backgroundImage;

    public BackgroundPanel() {
        setLayout(new BorderLayout());
        setOpaque(true);

        try {
            backgroundImage = ImageIO.read(
                getClass().getResourceAsStream(
                    "/hotel_management/background/background_pic.jpg"
                )
            );
            if (backgroundImage != null) {
                System.out.println("✅ Background Image Loaded!");
            } else {
                System.out.println("❌ Background image resource returned null.");
            }
        } catch (IOException e) {
            System.out.println("❌ Image load error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("❌ Resource not found: " + e.getMessage());
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                                RenderingHints.VALUE_RENDER_QUALITY);
            // Draw image stretched to fill full panel
            g2.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            // Semi-transparent dark overlay so UI text stays readable
            g2.setColor(new Color(0, 0, 0, 100));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
        } else {
            // Fallback gradient if image missing
            Graphics2D g2 = (Graphics2D) g.create();
            GradientPaint gp = new GradientPaint(
                0, 0, new Color(13, 71, 161),
                0, getHeight(), new Color(5, 40, 100)
            );
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
        }
    }
}
