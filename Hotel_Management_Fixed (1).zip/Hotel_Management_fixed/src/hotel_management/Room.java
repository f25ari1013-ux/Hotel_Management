/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel_management;
/**
 *
 * @author iAT
 */
// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
public class Room {
   private int roomNo;
   private String type;
   private double pricePerDay;
   private boolean isAvailable;

   public Room(int var1, String var2, double var3) {
      if (var2 != null && !var2.isEmpty()) {
         this.roomNo = var1;
         this.type = var2;
         this.pricePerDay = var3;
         this.isAvailable = true;
      } else {
         throw new IllegalArgumentException("Room type cannot be empty");
      }
   }

   public int getRoomNo() {
      return this.roomNo;
   }

   public String getType() {
      return this.type;
   }

   public double getPricePerDay() {
      return this.pricePerDay;
   }

   public boolean isAvailable() {
      return this.isAvailable;
   }

   public void bookRoom() {
      if (!this.isAvailable) {
         System.out.println("Room already booked!");
      } else {
         this.isAvailable = false;
      }
   }

   public void checkOut() {
      if (this.isAvailable) {
         System.out.println("Room already available!");
      } else {
         this.isAvailable = true;
      }
   }

   public String toString() {
      return "Room No: " + this.roomNo + ", Type: " + this.type + ", Price/Day: " + this.pricePerDay + ", Available: " + (this.isAvailable ? "Yes" : "No");
   }
}

