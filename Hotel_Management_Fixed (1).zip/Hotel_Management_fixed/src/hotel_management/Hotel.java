package hotel_management;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Hotel {

    private List<Room> rooms;
    private List<Booking> bookings;

    // ✅ ADD THESE
    private String name;
    private String location;
    private String contact;

    public Hotel() {
        rooms = new ArrayList<>();
        bookings = new ArrayList<>();
    }

    // ✅ SETTERS
    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    // ✅ GETTERS
    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getContact() {
        return contact;
    }

    // Existing methods
    public void addRoom(Room room) {
        rooms.add(room);
    }

    public List<Room> viewTotalRooms() {
        return new ArrayList<>(rooms);
    }

    public List<Room> viewAvailableRooms() {
        List<Room> available = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()) {
                available.add(room);
            }
        }
        return available;
    }

    public Booking bookRoom(int roomNo, Customer customer, int days, double mealCharges) {

        for (Room room : rooms) {
            if (room.getRoomNo() == roomNo && room.isAvailable()) {

                room.bookRoom();

                Booking booking = new Booking(room, customer, days, mealCharges);

                bookings.add(booking);
                saveBookingsToFile();
                return booking;
            }
        }
        return null;
    }

    public boolean checkOut(int bookingId) {

        Booking toRemove = null;

        for (Booking booking : bookings) {
            if (booking.getBookingId() == bookingId) {
                booking.getRoom().checkOut();
                toRemove = booking;
                break;
            }
        }

        if (toRemove != null) {
            bookings.remove(toRemove);
            saveBookingsToFile();
            return true;
        }

        return false;
    }

    public List<Booking> getBookings() {
        return new ArrayList<>(bookings);
    }

    // File save/load (same as before)
    public void saveBookingsToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("bookings.txt"))) {
            for (Booking booking : bookings) {
                writer.println(
                        booking.getBookingId() + "," +
                        booking.getRoom().getRoomNo() + "," +
                        booking.getCustomer().getName() + "," +
                        booking.getCustomer().getId() + "," +
                        booking.getCustomer().getPhone() + "," +
                        booking.getDays() + "," +
                        booking.getTotalBill()
                );
            }
        } catch (IOException e) {
            System.out.println("Error saving file");
        }
    }

    public void loadBookingsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("bookings.txt"))) {

            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length >= 7) {

                    int roomNo = Integer.parseInt(parts[1]);
                    String name = parts[2];
                    String id = parts[3];
                    String phone = parts[4];
                    int days = Integer.parseInt(parts[5]);

                    Room room = null;

                    for (Room r : rooms) {
                        if (r.getRoomNo() == roomNo) {
                            room = r;
                            break;
                        }
                    }
                    

                    if (room != null) {
                        Customer customer = new Customer(name, id, phone);
                        Booking booking = new Booking(room, customer, days, 0);
                        bookings.add(booking);
                        room.bookRoom();
                    }
                }
            }

        } catch (IOException e) {
            System.out.println("File not found (first run OK)");
        }
    }
}